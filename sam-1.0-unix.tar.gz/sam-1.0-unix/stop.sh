#!/bin/bash

docker-compose -p sam down

