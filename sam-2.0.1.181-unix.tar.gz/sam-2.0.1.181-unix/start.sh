#!/bin/bash

docker-compose -p sam up -d
